package Practica4_Oracle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class AccesoOracle {

	private Connection con;

	void abrirConexion() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "Practica4_Oracle", "12345");
			System.out.println("Conexion OK");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 */
	void cerrarConexion() {
		try {
			System.out.println("Conexion cerrada");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void mostrarContactos() {
		try {
			// Create a statement
			Statement st = con.createStatement();

			/*
			 * insert into misalumnos values ('id001', persona('Kiril Pangarov',
			 * '967123456'));
			 * 
			 * 
			 * 
			 * insert into misalumnos values ('id001', persona('Juan Dominguez',
			 * '967123499'));
			 * 
			 * 
			 * 
			 * 
			 * delete from misalumnos al where al.DATOS_PERSONALES.nombre like 'Juan
			 * Dominguez';
			 * 
			 * select * from misalumnos;
			 * 
			 * select al.DATOS_PERSONALES.telefono from misalumnos al where
			 * al.DATOS_PERSONALES.nombre like 'Kiril Pangarov';
			 * 
			 * 
			 * SELECT a.matriculado.id_estudiante, a.matriculado.datos_personales.telefono
			 * FROM admitidos a;
			 * 
			 * select datos_personales from misalumnos;
			 */

			ResultSet resul = st.executeQuery("SELECT c.nombre, c.telefono FROM contactos c");
			System.out.println("INFORMACION DE CONTACTOS--------------");
			while (resul.next()) {
				// aquí tambien podriamos poner resul.getInt("nif");
				System.out.printf("\nNOMBRE: %s\nTELEFONO: %s", resul.getString(1), resul.getString(2));
			}
			System.out.println("\n--------------");
			resul.close();
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
