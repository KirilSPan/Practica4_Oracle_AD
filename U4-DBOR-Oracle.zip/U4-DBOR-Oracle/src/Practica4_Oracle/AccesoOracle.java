package Practica4_Oracle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.Statement;
import java.sql.Struct;

public class AccesoOracle {

	private Connection con;

	void abrirConexion() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "Practica4_Oracle", "12345");
			System.out.println("Conexion OK");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 */
	void cerrarConexion() {
		try {
			System.out.println("Conexion cerrada");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void crearAlumno(String idAlum, String nomPersona, int telPersona) {
		// TODO Auto-generated method stub

		try {
			String personaString = String.format("persona('%s', '%d')", nomPersona, telPersona);

			PreparedStatement sentencia = con
					.prepareStatement("insert into misalumnos values(?, " + personaString + ")");

			// PreparedStatement sentencia = con.prepareStatement("insert into misalumnos
			// values(? , ?)");
			sentencia.setString(1, idAlum);
			// sentencia.setObject(2,persona(nomPersona, nomPersona));
			// sentencia.setObject(2, String.valueOf(telPersona));
			sentencia.execute();
			System.out.println("Exito");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private Object persona(String nomPersona, String telPersona) {
		// TODO Auto-generated method stub
		return null;
	}

	public void buscarAlumno_porID(String idAlum) {
		try {
			PreparedStatement sentencia = con.prepareStatement("select * from misalumnos where id = ?");
			sentencia.setString(1, idAlum);
			ResultSet resultado = sentencia.executeQuery();

			if (resultado.next()) {
				String nombre = resultado.getString("nombre");
				int telefono = resultado.getInt("telefono");
				System.out.println("ID: " + idAlum + ", Nombre: " + nombre + ", Teléfono: " + telefono);
			} else {
				System.out.println("No se encontró ningún alumno con el ID: " + idAlum);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void eliminarAlumno_porID(String idAlum) {
		try {
			PreparedStatement sentencia = con.prepareStatement("delete from misalumnos where id = ?");
			sentencia.setString(1, idAlum);
			int filasEliminadas = sentencia.executeUpdate();

			if (filasEliminadas > 0) {
				System.out.println("Se eliminó el alumno con ID: " + idAlum + " exitosamente.");
			} else {
				System.out.println("No se encontró ningún alumno con el ID: " + idAlum + " para eliminar.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void buscarAlumnoPorNombreP(String nombrePersona) {
		try {
			PreparedStatement sentencia = con.prepareStatement(
					"SELECT al.ID_ESTUDIANTE, al.DATOS_PERSONALES FROM misalumnos al WHERE al.DATOS_PERSONALES.nombre = ?");
			sentencia.setString(1, nombrePersona);
			ResultSet resultado = sentencia.executeQuery();

			if (resultado.next()) {
				String idAlum = resultado.getString("ID_ESTUDIANTE");
				Object datosPersonales = resultado.getObject("DATOS_PERSONALES");

				// Accessing object attributes
				String nombre = ((Struct) datosPersonales).getAttributes()[0].toString();
				String telefono = ((Struct) datosPersonales).getAttributes()[1].toString();

				System.out.println("ID: " + idAlum + ", Nombre: " + nombre + ", Teléfono: " + telefono);
			} else {
				System.out.println("No se encontró ningún alumno con el nombre: " + nombrePersona);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void eliminarAlumnoPorNombreP(String nombrePersona) {
		try {
			PreparedStatement sentencia = con
					.prepareStatement("delete from misalumnos al where persona.DATOS_PERSONALES.nombre = ?");
			sentencia.setString(1, nombrePersona);
			int filasEliminadas = sentencia.executeUpdate();

			if (filasEliminadas > 0) {
				System.out.println("Se eliminaron los alumnos con nombre: " + nombrePersona + " exitosamente.");
			} else {
				System.out.println("No se encontró ningún alumno con el nombre: " + nombrePersona + " para eliminar.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void obtenerDatosPersonales() {
		try {
			PreparedStatement sentencia = con.prepareStatement("select datos_personales from misalumnos");
			ResultSet resultado = sentencia.executeQuery();

			while (resultado.next()) {
				// Assuming datos_personales is of type Struct
				Struct datosObjeto = (Struct) resultado.getObject("datos_personales");

				// Assuming the Struct has two attributes: nombre and telefono
				Object[] datosArray = datosObjeto.getAttributes();
				String nombre = (String) datosArray[0];
				String telefono = (String) datosArray[1];

				System.out.println("Nombre: " + nombre + ", Teléfono: " + telefono);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void obtenerTelefonosEstudiantes() {
		try {
			PreparedStatement sentencia = con
					.prepareStatement("SELECT a.MATRICULADO.DATOS_PERSONALES FROM ADMITIDOS a");
			ResultSet resultado = sentencia.executeQuery();

			while (resultado.next()) {

				Struct estudianteObjeto = (Struct) resultado.getObject("matriculado.datos_personales");

				Object[] attributes = estudianteObjeto.getAttributes();
				String datosPersonales = (String) attributes[1]; // Assuming datos_personales is the second attribute

				System.out.println("Teléfono: " + datosPersonales);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void mostrarContactos() {
		try {
			// Create a statement
			Statement st = con.createStatement();

			/*
			 * insert into misalumnos values ('id001', persona('Kiril Pangarov',
			 * '967123456'));
			 * 
			 * 
			 * 
			 * insert into misalumnos values ('id001', persona('Juan Dominguez',
			 * '967123499'));
			 * 
			 * 
			 * 
			 * 
			 * delete from misalumnos al where al.DATOS_PERSONALES.nombre like 'Juan
			 * Dominguez';
			 * 
			 * select * from misalumnos;
			 * 
			 * select al.DATOS_PERSONALES.telefono from misalumnos al where
			 * al.DATOS_PERSONALES.nombre like 'Kiril Pangarov';
			 * 
			 * 
			 * SELECT a.matriculado.id_estudiante, a.matriculado.datos_personales.telefono
			 * FROM admitidos a;
			 * 
			 * select datos_personales from misalumnos;
			 */

			ResultSet resul = st.executeQuery("SELECT c.nombre, c.telefono FROM contactos c");
			System.out.println("INFORMACION DE CONTACTOS--------------");
			while (resul.next()) {
				// aquí tambien podriamos poner resul.getInt("nif");
				System.out.printf("\nNOMBRE: %s\nTELEFONO: %s", resul.getString(1), resul.getString(2));
			}
			System.out.println("\n--------------");
			resul.close();
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
